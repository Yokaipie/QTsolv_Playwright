const devConfig = {
    ...require('./global.config'),
    environment: 'development',
    location: 'Bengaluru, India',
  };
  
  module.exports = devConfig;
  