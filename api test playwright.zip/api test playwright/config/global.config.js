const globalConfig = {
    baseURL: 'https://www.qtsolv.com',
    CareerURL: 'https://www.qtsolv.com/careers/',
    RedirectCareerURL: 'https://www.qtsolv.com/career-details/?jobid=1154',
    AboutUsURL: 'https://www.qtsolv.com/about-us/',
    SolutionURL: 'https://www.qtsolv.com/solutions/'

  };
  
  module.exports = globalConfig;
  