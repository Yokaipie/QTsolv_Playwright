const stagingConfig = {
    ...require('./global.config'),
    environment: 'staging',
    location: 'Bengaluru, India',
  };
  
  module.exports = stagingConfig;
  