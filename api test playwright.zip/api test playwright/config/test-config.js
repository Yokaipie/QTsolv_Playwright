const testConfig = {
    ...require('./global.config'),
    environment: 'test',
    location: 'Bengaluru, India',
  };
  
  module.exports = testConfig;
  